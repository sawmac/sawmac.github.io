$(document).ready(function() {
  $("#tabs").tabs({
    cache: true,
    spinner: 'Loading'
  });
});